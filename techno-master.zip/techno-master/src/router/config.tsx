
import { lazy } from 'react';
import { RouteObject } from 'react-router-dom';

const HomePage = lazy(() => import('../pages/home/page'));
const SoftwarePage = lazy(() => import('../pages/software/page'));
const ServicesPage = lazy(() => import('../pages/services/page'));
const HardwarePage = lazy(() => import('../pages/hardware/page'));
const PortfolioPage = lazy(() => import('../pages/portfolio/page'));
const AboutPage = lazy(() => import('../pages/about/page'));
const ContactPage = lazy(() => import('../pages/contact/page'));
const NotFoundPage = lazy(() => import('../pages/NotFound'));

const routes: RouteObject[] = [
  {
    path: '/',
    element: <HomePage />,
  },
  {
    path: '/software',
    element: <SoftwarePage />,
  },
  {
    path: '/services',
    element: <ServicesPage />,
  },
  {
    path: '/hardware',
    element: <HardwarePage />,
  },
  {
    path: '/portfolio',
    element: <PortfolioPage />,
  },
  {
    path: '/about',
    element: <AboutPage />,
  },
  {
    path: '/contact',
    element: <ContactPage />,
  },
  {
    path: '*',
    element: <NotFoundPage />,
  },
];

export default routes;
