
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';

const HomePage = () => {
  const softwareSolutions = [
    {
      title: "Command, Control & Intelligence (C2I) System",
      description: "Integrates real-time data from land, air, and sea forces into a unified national command network.",
      icon: "ri-command-line"
    },
    {
      title: "Intelligence Fusion & Data Analysis Platform",
      description: "Aggregates multi-source intelligence (AI-driven) for threat detection and decision support.",
      icon: "ri-brain-line"
    },
    {
      title: "Cyber Defence & Threat Intelligence Platform",
      description: "Provides network protection, incident monitoring, and AI-based intrusion detection.",
      icon: "ri-shield-check-line"
    },
    {
      title: "UAV Mission Planning & Flight Management",
      description: "Controls autonomous drones, route optimization, and mission reporting.",
      icon: "ri-flight-takeoff-line"
    }
  ];

  const hardwareProducts = [
    {
      title: "IMSI-Catcher Drone",
      description: "Advanced mobile-signal intelligence gathering for security operations.",
      image: "https://readdy.ai/api/search-image?query=Advanced%20military%20surveillance%20drone%20with%20signal%20intelligence%20equipment%20flying%20over%20secure%20facility%2C%20modern%20defense%20technology%2C%20professional%20lighting%2C%20clean%20background%20highlighting%20the%20sophisticated%20UAV%20system&width=400&height=300&seq=1&orientation=landscape"
    },
    {
      title: "Fixed-Wing VTOL Surveillance Drone",
      description: "Long-range patrol and border monitoring with vertical takeoff capabilities.",
      image: "https://readdy.ai/api/search-image?query=Fixed-wing%20VTOL%20surveillance%20drone%20with%20advanced%20camera%20systems%2C%20military%20grade%20UAV%20for%20border%20patrol%2C%20sleek%20aerodynamic%20design%2C%20professional%20defense%20technology%20photography&width=400&height=300&seq=2&orientation=landscape"
    },
    {
      title: "Drone Jammers",
      description: "Electronic warfare systems that neutralize hostile UAVs effectively.",
      image: "https://readdy.ai/api/search-image?query=Military%20drone%20jammer%20equipment%2C%20electronic%20warfare%20defense%20system%2C%20tactical%20anti-UAV%20technology%2C%20professional%20defense%20hardware%20photography%20with%20clean%20background&width=400&height=300&seq=3&orientation=landscape"
    },
    {
      title: "Long-Range PTZ Cameras",
      description: "Day-night perimeter security with pan-tilt-zoom capabilities.",
      image: "https://readdy.ai/api/search-image?query=Professional%20long-range%20PTZ%20security%20camera%20system%2C%20military%20grade%20surveillance%20equipment%2C%20day-night%20vision%20technology%2C%20mounted%20on%20tactical%20platform%20with%20clean%20background&width=400&height=300&seq=4&orientation=landscape"
    }
  ];

  const stats = [
    { number: "50+", label: "Defence Projects", icon: "ri-shield-line" },
    { number: "15+", label: "Years Experience", icon: "ri-time-line" },
    { number: "100%", label: "Nigerian Innovation", icon: "ri-flag-line" },
    { number: "24/7", label: "Support Available", icon: "ri-customer-service-line" }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section 
        className="relative bg-cover bg-center bg-no-repeat min-h-screen flex items-center"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.4)), url('https://readdy.ai/api/search-image?query=Modern%20military%20command%20center%20with%20advanced%20surveillance%20technology%2C%20multiple%20screens%20showing%20UAV%20feeds%20and%20intelligence%20data%2C%20professional%20defense%20facility%20interior%2C%20high-tech%20atmosphere%20with%20blue%20lighting%2C%20clean%20and%20sophisticated%20environment&width=1920&height=1080&seq=5&orientation=landscape')`
        }}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-8 w-full">
          <div className="max-w-3xl">
            <h1 className="text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
              Advanced <strong>Defence</strong> & <strong>Surveillance</strong> Technologies
            </h1>
            <p className="text-xl text-gray-200 mb-8 leading-relaxed">
              Technoguard Nigeria Ltd develops and integrates cutting-edge UAV systems, AI-driven intelligence platforms, and cyber defence solutions for national security and industrial growth.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="bg-blue-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-colors whitespace-nowrap cursor-pointer">
                Explore Solutions
              </button>
              <button className="border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white hover:text-gray-900 transition-colors whitespace-nowrap cursor-pointer">
                Contact Us
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className={`${stat.icon} text-white text-2xl`}></i>
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-2">{stat.number}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                Our <strong>Mission</strong>: Innovate, Secure, Sustain
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                Through local innovation and international partnerships, we strengthen Nigeria's self-reliance in defence technology. Our mission is to build a safer, smarter future for the nation.
              </p>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center mt-1">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Local Innovation</h4>
                    <p className="text-gray-600">Developing cutting-edge solutions tailored for Nigerian defence needs</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center mt-1">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">International Partnerships</h4>
                    <p className="text-gray-600">Collaborating with global leaders in defence technology</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center mt-1">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">National Security</h4>
                    <p className="text-gray-600">Strengthening Nigeria's defence capabilities and self-reliance</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://readdy.ai/api/search-image?query=Nigerian%20defense%20technology%20engineers%20working%20on%20advanced%20UAV%20systems%20in%20modern%20laboratory%2C%20diverse%20team%20of%20professionals%2C%20high-tech%20equipment%20and%20computers%2C%20professional%20lighting%2C%20clean%20modern%20facility&width=600&height=500&seq=6&orientation=landscape"
                alt="Technoguard team working on defence technology"
                className="rounded-lg shadow-xl object-cover w-full h-96"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Software Solutions */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              <strong>Defence Software</strong> Solutions
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive software platforms integrating AI, real-time data processing, and advanced analytics for national security operations.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {softwareSolutions.map((solution, index) => (
              <div key={index} className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-6">
                  <i className={`${solution.icon} text-blue-600 text-xl`}></i>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">{solution.title}</h3>
                <p className="text-gray-600 leading-relaxed">{solution.description}</p>
                <button className="mt-6 text-blue-600 font-semibold hover:text-blue-700 transition-colors cursor-pointer">
                  Learn More <i className="ri-arrow-right-line ml-1"></i>
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Hardware Products */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Advanced <strong>Defence Hardware</strong>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Cutting-edge surveillance and electronic warfare systems designed and manufactured for superior performance in critical operations.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8" data-product-shop>
            {hardwareProducts.map((product, index) => (
              <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
                <div className="h-48 overflow-hidden">
                  <img 
                    src={product.image}
                    alt={product.title}
                    className="w-full h-full object-cover object-top hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-3">{product.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed mb-4">{product.description}</p>
                  <button className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap cursor-pointer">
                    View Details
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-indigo-700">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Strengthen Your <strong>Defence Capabilities</strong>?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Partner with Technoguard Nigeria Ltd to access cutting-edge defence and surveillance technologies tailored for your security needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-blue-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-colors whitespace-nowrap cursor-pointer">
              Request Consultation
            </button>
            <a
              href="/Technoguard-Profile.pdf"
              target="_blank"
              rel="noopener noreferrer"
              download="Technoguard-Profile.pdf"
              className="border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors whitespace-nowrap cursor-pointer"
            >
              Download Brochure
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default HomePage;
