
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';

const AboutPage = () => {
  const stats = [
    { number: "15+", label: "Years of Experience" },
    { number: "50+", label: "Defence Projects" },
    { number: "100+", label: "Security Personnel Trained" },
    { number: "24/7", label: "Support Available" }
  ];

  const values = [
    {
      icon: "ri-lightbulb-line",
      title: "Innovation",
      description: "Pioneering advanced defence technologies through continuous research and development"
    },
    {
      icon: "ri-shield-check-line",
      title: "Security",
      description: "Ensuring national security through robust and reliable defence solutions"
    },
    {
      icon: "ri-leaf-line",
      title: "Sustainability",
      description: "Building long-term capabilities for Nigeria's defence technology independence"
    },
    {
      icon: "ri-team-line",
      title: "Partnership",
      description: "Collaborating with international partners while strengthening local expertise"
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section 
        className="relative bg-cover bg-center bg-no-repeat py-24"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.5)), url('https://readdy.ai/api/search-image?query=Modern%20Nigerian%20defense%20technology%20facility%20with%20engineers%20working%20on%20advanced%20surveillance%20systems%2C%20UAV%20development%2C%20and%20AI%20platforms%2C%20professional%20corporate%20environment%20with%20Nigerian%20flag&width=1920&height=800&seq=14&orientation=landscape')`
        }}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h1 className="text-5xl lg:text-6xl font-bold text-white mb-6">
            About <strong>Technoguard</strong> Nigeria Ltd
          </h1>
          <p className="text-xl text-gray-200 max-w-3xl mx-auto leading-relaxed">
            Innovate, Secure, and Sustain — Building a safer, smarter future for Nigeria through advanced defence and surveillance technologies.
          </p>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                Our <strong>Mission</strong>
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                Technoguard Nigeria Ltd develops and integrates advanced defence and surveillance technologies for national security and industrial growth. We focus on UAV systems, AI-driven intelligence platforms, smart manufacturing, and cyber defence solutions.
              </p>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                The company designs, builds, and deploys drones, sensors, and command systems tailored for military and civil agencies. Through local innovation and international partnerships, we strengthen Nigeria's self-reliance in defence technology.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                Our mission is to innovate, secure, and sustain—building a safer, smarter future for the nation through cutting-edge defence software solutions.
              </p>
            </div>
            <div className="relative">
              <img 
                src="https://readdy.ai/api/search-image?query=Nigerian%20defense%20engineers%20working%20on%20advanced%20UAV%20systems%20and%20AI%20platforms%2C%20modern%20technology%20development%20facility%2C%20professional%20team%20collaboration%20with%20high-tech%20equipment&width=600&height=500&seq=15&orientation=landscape"
                alt="Technoguard mission"
                className="rounded-lg shadow-xl object-cover w-full h-96"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Our <strong>Impact</strong> in Numbers
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Delivering measurable results in defence technology and national security enhancement.
            </p>
          </div>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl lg:text-5xl font-bold text-blue-600 mb-2">{stat.number}</div>
                <div className="text-gray-600 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Our <strong>Core Values</strong>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              The principles that guide our commitment to excellence in defence technology and national security.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className={`${value.icon} text-blue-600 text-2xl`}></i>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{value.title}</h3>
                <p className="text-gray-600 leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Expert <strong>Leadership Team</strong>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our experienced team combines deep technical expertise with strategic vision to deliver world-class defence solutions.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <img 
                src="https://static.readdy.ai/image/3d693276a5424479ffa5f1cc868e7c58/6887b93d88d3f3631b1f93385f8d150f.jpeg"
                alt="CEO"
                className="w-48 h-48 rounded-full mx-auto mb-4 object-cover object-top"
              />
              <h3 className="text-xl font-bold text-gray-900 mb-1">Alh. Suleiman Chiroma</h3>
              <p className="text-blue-600 font-medium mb-2">Chief Executive Officer</p>
              <p className="text-gray-600 text-sm">15+ years in defence technology and strategic leadership</p>
            </div>
            <div className="text-center">
              <img 
                src="https://readdy.ai/api/search-image?query=Professional%20Nigerian%20technology%20director%2C%20experienced%20engineer%20in%20modern%20tech%20facility%2C%20corporate%20headshot%20with%20clean%20background&width=300&height=300&seq=17&orientation=squarish"
                alt="CTO"
                className="w-48 h-48 rounded-full mx-auto mb-4 object-cover"
              />
              <h3 className="text-xl font-bold text-gray-900 mb-1">Eng. Fatima Abdullahi</h3>
              <p className="text-blue-600 font-medium mb-2">Chief Technology Officer</p>
              <p className="text-gray-600 text-sm">Expert in AI systems and UAV technology development</p>
            </div>
            <div className="text-center">
              <img 
                src="https://static.readdy.ai/image/3d693276a5424479ffa5f1cc868e7c58/648c9d65fefbbe33506d53d0ef390229.png"
                alt="COO"
                className="w-48 h-48 rounded-full mx-auto mb-4 object-cover object-top"
              />
              <h3 className="text-xl font-bold text-gray-900 mb-1">Mr. Fuad Maqary</h3>
              <p className="text-blue-600 font-medium mb-2">Chief Operations Officer</p>
              <p className="text-gray-600 text-sm">10+ years experience in manufacturing and management</p>
            </div>
          </div>
        </div>
      </section>

      {/* Strategic Partners Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Strategic <strong>Partners</strong>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Collaborating with leading international defence technology companies to deliver world-class solutions and strengthen Nigeria's defence capabilities.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white rounded-xl p-6 shadow-lg text-center hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-global-line text-red-600 text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">North Jiarui Defense Technology</h3>
              <p className="text-gray-600 text-sm mb-2">China</p>
              <p className="text-gray-500 text-xs">Advanced defence systems and technology solutions</p>
            </div>
            
            <div className="bg-white rounded-xl p-6 shadow-lg text-center hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-computer-line text-red-600 text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Argus Information Technology Co., Ltd.</h3>
              <p className="text-gray-600 text-sm mb-2">China</p>
              <p className="text-gray-500 text-xs">Information technology and surveillance systems</p>
            </div>
            
            <div className="bg-white rounded-xl p-6 shadow-lg text-center hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-shield-line text-red-600 text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">HAVELSAN A.S.</h3>
              <p className="text-gray-600 text-sm mb-2">Turkey</p>
              <p className="text-gray-500 text-xs">Defence electronics and command control systems</p>
            </div>
            
            <div className="bg-white rounded-xl p-6 shadow-lg text-center hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-security-line text-red-600 text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">ASISGUARD A.S.</h3>
              <p className="text-gray-600 text-sm mb-2">Turkey</p>
              <p className="text-gray-500 text-xs">Security and surveillance technology solutions</p>
            </div>
            
            <div className="bg-white rounded-xl p-6 shadow-lg text-center hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-tools-line text-green-600 text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">JODDB</h3>
              <p className="text-gray-600 text-sm mb-2">Jordan</p>
              <p className="text-gray-500 text-xs">Jordan Design and Development Bureau</p>
            </div>
            
            <div className="bg-white rounded-xl p-6 shadow-lg text-center hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-rocket-line text-blue-600 text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Metasync</h3>
              <p className="text-gray-600 text-sm mb-2">USA</p>
              <p className="text-gray-500 text-xs">Advanced technology and innovation solutions</p>
            </div>
            
            <div className="bg-white rounded-xl p-6 shadow-lg text-center hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-building-line text-blue-600 text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">FORMELO INC.</h3>
              <p className="text-gray-600 text-sm mb-2">USA</p>
              <p className="text-gray-500 text-xs">Technology development and manufacturing</p>
            </div>
            
            <div className="bg-white rounded-xl p-6 shadow-lg text-center hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-hammer-line text-green-600 text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Espial-i Forge</h3>
              <p className="text-gray-600 text-sm mb-2">Nigeria</p>
              <p className="text-gray-500 text-xs">Local technology development and manufacturing</p>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <p className="text-lg text-gray-600 max-w-4xl mx-auto">
              Through these strategic partnerships, we combine global expertise with local knowledge to deliver cutting-edge defence solutions tailored for Nigeria's unique security challenges and operational requirements.
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-indigo-700">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Join Us in <strong>Securing Nigeria's Future</strong>
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Partner with Technoguard Nigeria Ltd to strengthen national security through innovative defence technologies and solutions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-blue-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-colors whitespace-nowrap cursor-pointer">
              Partner With Us
            </button>
            <button className="border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors whitespace-nowrap cursor-pointer">
              Learn More
            </button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default AboutPage;
