
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';

const SoftwarePage = () => {
  const softwareSolutions = [
    {
      title: "Command, Control & Intelligence (C2I) System",
      description: "Integrates real-time data from land, air, and sea forces into a unified national command network for comprehensive situational awareness.",
      features: ["Real-time data integration", "Multi-domain command", "Unified dashboard", "Secure communications"],
      icon: "ri-command-line",
      category: "Command & Control"
    },
    {
      title: "Intelligence Fusion & Data Analysis Platform",
      description: "Aggregates multi-source intelligence using AI-driven analytics for advanced threat detection and strategic decision support.",
      features: ["AI-powered analysis", "Multi-source integration", "Threat prediction", "Decision support"],
      icon: "ri-brain-line",
      category: "Intelligence"
    },
    {
      title: "Cyber Defence & Threat Intelligence Platform (CDTI)",
      description: "Comprehensive network protection with real-time incident monitoring and AI-based intrusion detection capabilities.",
      features: ["Network protection", "Incident monitoring", "AI intrusion detection", "Threat intelligence"],
      icon: "ri-shield-check-line",
      category: "Cybersecurity"
    },
    {
      title: "UAV Mission Planning & Flight Management Software",
      description: "Advanced autonomous drone control system with route optimization, mission planning, and comprehensive reporting.",
      features: ["Mission planning", "Route optimization", "Autonomous control", "Real-time monitoring"],
      icon: "ri-flight-takeoff-line",
      category: "UAV Systems"
    },
    {
      title: "Border & Maritime Surveillance Suite",
      description: "Combines live UAV feeds, radar data, and AI image recognition for comprehensive perimeter security monitoring.",
      features: ["Live UAV feeds", "Radar integration", "AI recognition", "Perimeter monitoring"],
      icon: "ri-map-2-line",
      category: "Surveillance"
    },
    {
      title: "Digital Defence Training & Simulation (VR/AR)",
      description: "Immersive military training environments and war-gaming scenarios using virtual and augmented reality technologies.",
      features: ["VR/AR training", "War-gaming scenarios", "Immersive environments", "Performance analytics"],
      icon: "ri-vr-box-line",
      category: "Training"
    },
    {
      title: "Electronic Warfare (EW) Mission Suite",
      description: "Advanced modeling, simulation, and analysis of signal intelligence and counter-intrusion scenarios.",
      features: ["Signal intelligence", "EW simulation", "Counter-intrusion", "Mission analysis"],
      icon: "ri-radar-line",
      category: "Electronic Warfare"
    },
    {
      title: "Smart Manufacturing & MES (Factory Automation)",
      description: "Comprehensive management of defence equipment production, quality control, and robotic assembly systems.",
      features: ["Production management", "Quality control", "Robotic assembly", "Real-time monitoring"],
      icon: "ri-robot-line",
      category: "Manufacturing"
    },
    {
      title: "Secure Communication & Encryption Network",
      description: "Ensures encrypted voice, video, and data transfer across all agencies with military-grade security protocols.",
      features: ["Military-grade encryption", "Multi-channel communication", "Secure protocols", "Agency integration"],
      icon: "ri-lock-line",
      category: "Communications"
    },
    {
      title: "Defence Human Capital & Biometric Management System",
      description: "Comprehensive personnel records management, access control, and AI-driven performance tracking system.",
      features: ["Personnel management", "Biometric access", "Performance tracking", "Security clearance"],
      icon: "ri-user-settings-line",
      category: "Human Resources"
    }
  ];

  const categories = ["All", "Command & Control", "Intelligence", "Cybersecurity", "UAV Systems", "Surveillance", "Training"];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section 
        className="relative bg-cover bg-center bg-no-repeat py-24"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.5)), url('https://readdy.ai/api/search-image?query=Advanced%20military%20software%20interface%20showing%20multiple%20screens%20with%20data%20analytics%2C%20command%20control%20systems%2C%20AI-powered%20intelligence%20platforms%2C%20modern%20defense%20technology%20center%20with%20blue%20lighting%20and%20professional%20atmosphere&width=1920&height=800&seq=7&orientation=landscape')`
        }}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold text-white mb-6">
            <strong>Defence Software</strong> Solutions
          </h1>
          <p className="text-xl text-gray-200 max-w-3xl mx-auto">
            Comprehensive software platforms integrating AI, real-time data processing, and advanced analytics for national security operations and defence management.
          </p>
        </div>
      </section>

      {/* Category Filter */}
      <section className="py-8 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-4">
            {categories.map((category) => (
              <button
                key={category}
                className="px-6 py-2 rounded-full border border-gray-300 text-gray-700 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-colors whitespace-nowrap cursor-pointer"
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Software Solutions Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {softwareSolutions.map((solution, index) => (
              <div key={index} className="bg-white rounded-xl border border-gray-200 p-8 hover:shadow-xl transition-shadow">
                <div className="flex items-center justify-between mb-6">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <i className={`${solution.icon} text-blue-600 text-xl`}></i>
                  </div>
                  <span className="text-xs font-semibold text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
                    {solution.category}
                  </span>
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-4">{solution.title}</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">{solution.description}</p>
                
                <div className="mb-6">
                  <h4 className="font-semibold text-gray-900 mb-3">Key Features:</h4>
                  <ul className="space-y-2">
                    {solution.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center text-sm text-gray-600">
                        <i className="ri-check-line text-green-500 mr-2"></i>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="flex space-x-3">
                  <button className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors text-sm whitespace-nowrap cursor-pointer">
                    Learn More
                  </button>
                  <button className="flex-1 border border-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-50 transition-colors text-sm whitespace-nowrap cursor-pointer">
                    Request Demo
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Integration Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Integrated <strong>Defence Ecosystem</strong>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              All our software solutions integrate seamlessly with Technoguard's AI and C2I platforms for real-time control and comprehensive analysis.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-links-line text-white text-3xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Seamless Integration</h3>
              <p className="text-gray-600">
                All systems work together as a unified defence ecosystem with real-time data sharing and coordinated operations.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-cpu-line text-white text-3xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">AI-Powered Analytics</h3>
              <p className="text-gray-600">
                Advanced artificial intelligence drives decision-making processes and provides predictive insights for strategic planning.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-shield-check-line text-white text-3xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Military-Grade Security</h3>
              <p className="text-gray-600">
                All software platforms feature military-grade encryption and security protocols to protect sensitive defence data.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-indigo-700">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Deploy Advanced <strong>Defence Software</strong>?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Contact our team to discuss custom software solutions tailored to your specific defence and security requirements.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-blue-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-colors whitespace-nowrap cursor-pointer">
              Schedule Consultation
            </button>
            <button className="border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors whitespace-nowrap cursor-pointer">
              Download Technical Specs
            </button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default SoftwarePage;
