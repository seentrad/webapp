
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';

const HardwarePage = () => {
  const hardwareProducts = [
    {
      title: "IMSI-Catcher Drone",
      description: "Advanced mobile-signal intelligence drone capable of intercepting and analyzing cellular communications for security operations.",
      image: "https://readdy.ai/api/search-image?query=Advanced%20military%20drone%20with%20signal%20intelligence%20equipment%2C%20IMSI%20catcher%20technology%2C%20sleek%20black%20design%20with%20antennas%20and%20communication%20arrays%2C%20professional%20defense%20equipment%20photography%20with%20clean%20background&width=600&height=400&seq=9&orientation=landscape",
      features: [
        "Mobile signal interception",
        "Real-time data analysis",
        "Long-range operation capability",
        "Stealth design technology",
        "Multi-frequency support"
      ],
      specifications: {
        "Flight Time": "Up to 8 hours",
        "Range": "50km radius",
        "Payload": "15kg signal equipment",
        "Operating Altitude": "Up to 5000m"
      }
    },
    {
      title: "Fixed-Wing VTOL Surveillance Drone",
      description: "Long-range patrol and border monitoring drone with vertical takeoff and landing capabilities for versatile deployment.",
      image: "https://readdy.ai/api/search-image?query=Military%20fixed-wing%20VTOL%20surveillance%20drone%20with%20vertical%20takeoff%20capability%2C%20advanced%20camera%20systems%2C%20long-range%20patrol%20aircraft%2C%20professional%20defense%20equipment%20with%20clean%20background&width=600&height=400&seq=10&orientation=landscape",
      features: [
        "Vertical takeoff and landing",
        "Extended flight duration",
        "High-resolution surveillance cameras",
        "Weather-resistant design",
        "Autonomous flight modes"
      ],
      specifications: {
        "Flight Time": "Up to 12 hours",
        "Range": "200km radius",
        "Camera Resolution": "4K Ultra HD",
        "Max Speed": "150 km/h"
      }
    },
    {
      title: "Drone Jammers",
      description: "Sophisticated counter-drone systems that neutralize hostile UAVs through advanced signal jamming technology.",
      image: "https://readdy.ai/api/search-image?query=Military%20drone%20jammer%20system%2C%20counter-UAV%20defense%20equipment%2C%20signal%20jamming%20technology%2C%20portable%20defense%20system%20with%20antennas%20and%20control%20unit%2C%20professional%20equipment%20photography&width=600&height=400&seq=11&orientation=landscape",
      features: [
        "Multi-frequency jamming",
        "Rapid deployment capability",
        "Selective targeting system",
        "Portable and stationary options",
        "Real-time threat detection"
      ],
      specifications: {
        "Jamming Range": "Up to 5km",
        "Frequency Bands": "2.4GHz, 5.8GHz, GPS",
        "Power Output": "100W",
        "Deployment Time": "Under 5 minutes"
      }
    },
    {
      title: "Long-Range PTZ Cameras",
      description: "High-performance pan-tilt-zoom cameras for day-night perimeter security and surveillance operations with exceptional 20km range capability.",
      image: "https://static.readdy.ai/image/3d693276a5424479ffa5f1cc868e7c58/d632d6dcf4fd8c30eb80050eacaa2d9a.jpeg",
      features: [
        "360-degree pan capability",
        "High-zoom optical lens",
        "Infrared night vision",
        "Weather-proof housing",
        "AI-powered tracking"
      ],
      specifications: {
        "Zoom Range": "50x optical zoom",
        "Night Vision": "Up to 20km range",
        "Resolution": "4K Ultra HD",
        "Operating Temperature": "-40°C to +70°C"
      }
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section 
        className="relative bg-cover bg-center bg-no-repeat py-24"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.5)), url('https://readdy.ai/api/search-image?query=Advanced%20military%20hardware%20manufacturing%20facility%20with%20drones%2C%20surveillance%20equipment%2C%20and%20defense%20systems%2C%20high-tech%20production%20environment%20with%20professional%20lighting&width=1920&height=800&seq=13&orientation=landscape')`
        }}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h1 className="text-5xl lg:text-6xl font-bold text-white mb-6">
            Defence <strong>Hardware</strong> Solutions
          </h1>
          <p className="text-xl text-gray-200 max-w-3xl mx-auto leading-relaxed">
            Cutting-edge defence hardware designed and manufactured for surveillance, electronic warfare, and national security operations.
          </p>
        </div>
      </section>

      {/* Products Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Our <strong>Hardware</strong> Portfolio
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Locally-built defence hardware systems that integrate seamlessly with our AI and C2I software platforms for complete operational control.
            </p>
          </div>
          
          <div className="space-y-16" data-product-shop>
            {hardwareProducts.map((product, index) => (
              <div key={index} className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${index % 2 === 1 ? 'lg:grid-flow-col-dense' : ''}`}>
                <div className={index % 2 === 1 ? 'lg:col-start-2' : ''}>
                  <img 
                    src={product.image}
                    alt={product.title}
                    className="rounded-lg shadow-xl object-cover w-full h-96"
                  />
                </div>
                <div className={index % 2 === 1 ? 'lg:col-start-1' : ''}>
                  <h3 className="text-3xl font-bold text-gray-900 mb-4">{product.title}</h3>
                  <p className="text-lg text-gray-600 mb-6 leading-relaxed">{product.description}</p>
                  
                  <div className="mb-6">
                    <h4 className="text-lg font-semibold text-gray-900 mb-3">Key Features</h4>
                    <ul className="space-y-2">
                      {product.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-center text-gray-600">
                          <div className="w-4 h-4 bg-blue-600 rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                            <i className="ri-check-line text-white text-xs"></i>
                          </div>
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div className="mb-6">
                    <h4 className="text-lg font-semibold text-gray-900 mb-3">Specifications</h4>
                    <div className="grid grid-cols-2 gap-4">
                      {Object.entries(product.specifications).map(([key, value], specIndex) => (
                        <div key={specIndex} className="bg-white p-3 rounded-lg">
                          <div className="text-sm text-gray-500">{key}</div>
                          <div className="font-semibold text-gray-900">{value}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex space-x-4">
                    <button className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors whitespace-nowrap cursor-pointer">
                      Request Quote
                    </button>
                    <button className="border-2 border-blue-600 text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-blue-600 hover:text-white transition-colors whitespace-nowrap cursor-pointer">
                      Technical Specs
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://static.readdy.ai/image/3d693276a5424479ffa5f1cc868e7c58/d632d6dcf4fd8c30eb80050eacaa2d9a.jpeg"
            alt="Long-Range PTZ Camera System"
            className="rounded-lg shadow-xl object-contain w-full h-80 bg-gray-50"
          />
        </div>
        <div>
          <h3 className="text-2xl font-bold text-gray-900 mb-4">Advanced Surveillance Technology</h3>
          <p className="text-lg text-gray-600 mb-6 leading-relaxed">
            Our Long-Range PTZ Cameras deliver exceptional surveillance capabilities with up to 20km range, providing comprehensive perimeter security and monitoring solutions for critical infrastructure and border protection.
          </p>
          
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
              <span className="text-gray-700">Up to 20km surveillance range</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
              <span className="text-gray-700">Day and night vision capabilities</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
              <span className="text-gray-700">360° pan-tilt-zoom functionality</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
              <span className="text-gray-700">Weather-resistant design</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
              <span className="text-gray-700">AI-powered threat detection</span>
            </div>
          </div>
        </div>
      </div>

      {/* Integration Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Complete <strong>Defence Ecosystem</strong>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              All hardware systems integrate with Technoguard's AI and C2I software platforms for real-time control and analysis.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-cpu-line text-blue-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">AI Integration</h3>
              <p className="text-gray-600">Advanced AI algorithms for autonomous operation and intelligent analysis</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-command-line text-blue-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">C2I Control</h3>
              <p className="text-gray-600">Unified command and control interface for all hardware systems</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-shield-check-line text-blue-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Local Manufacturing</h3>
              <p className="text-gray-600">Designed and built in Nigeria for enhanced security and self-reliance</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-indigo-700">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Deploy <strong>Advanced Defence Hardware</strong>?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Contact us to discuss your hardware requirements and discover how our locally-manufactured systems can enhance your defence capabilities.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-blue-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-colors whitespace-nowrap cursor-pointer">
              Request Demo
            </button>
            <button className="border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors whitespace-nowrap cursor-pointer">
              Download Catalog
            </button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default HardwarePage;
