
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';

const ServicesPage = () => {
  const services = [
    {
      title: "Surveillance-as-a-Service (SaaS)",
      description: "Real-time aerial and ground surveillance using drones and long-range cameras with data feed subscription, live monitoring, and incident reporting.",
      icon: "ri-eye-line",
      clients: "Government agencies, oil companies, border security units, state police, private estates, and mining operators",
      features: [
        "Real-time aerial surveillance",
        "Ground monitoring systems",
        "Data feed subscription",
        "Live monitoring dashboard",
        "Incident reporting system"
      ]
    },
    {
      title: "Drone Mission & Patrol Services",
      description: "Contract-based drone deployment for reconnaissance, mapping, and infrastructure inspection with trained pilots and analysts.",
      icon: "ri-flight-takeoff-line",
      clients: "Per mission/hour billing or annual surveillance contracts",
      features: [
        "VTOL and fixed-wing missions",
        "Reconnaissance operations",
        "Infrastructure mapping",
        "Trained pilots and analysts",
        "Flexible billing options"
      ]
    },
    {
      title: "Electronic Warfare & Anti-Drone Protection",
      description: "On-site protection against unauthorized drones using Technoguard's Drone Jammer systems with real-time detection and countermeasure deployment.",
      icon: "ri-shield-check-line",
      clients: "Airports, military bases, VIP events, and oil installations",
      features: [
        "Real-time drone detection",
        "Countermeasure deployment",
        "Threat analysis reporting",
        "On-site protection systems",
        "24/7 monitoring capability"
      ]
    },
    {
      title: "Cyber Defence & Network Security Services",
      description: "Managed cyber protection, penetration testing, encryption integration, and digital forensics operating as a continuous Security Operations Center (SOC).",
      icon: "ri-shield-keyhole-line",
      clients: "Ministries, banks, and telecom companies",
      features: [
        "Managed cyber protection",
        "Penetration testing",
        "Encryption integration",
        "Digital forensics",
        "24/7 SOC operations"
      ]
    },
    {
      title: "Intelligence Fusion & Data Analytics",
      description: "AI-driven intelligence subscription service from field devices providing situational awareness dashboards and risk analytics for security agencies.",
      icon: "ri-brain-line",
      clients: "Security agencies and government departments",
      features: [
        "AI-driven intelligence analysis",
        "Multi-source data fusion",
        "Situational awareness dashboards",
        "Risk analytics reporting",
        "Real-time threat assessment"
      ]
    },
    {
      title: "IMSI-Capture & Mobile Signal Intelligence",
      description: "Licensed signal intelligence support for government security and counter-terror operations including mobile network mapping and geo-location analysis.",
      icon: "ri-signal-tower-line",
      clients: "Authorized defence and law-enforcement contracts only",
      features: [
        "Mobile network mapping",
        "SIM detection systems",
        "Geo-location analysis",
        "Signal intelligence gathering",
        "Counter-terror support"
      ]
    },
    {
      title: "Digital Training & Simulation Programs",
      description: "VR/AR-based defence training for police, military, and emergency-response teams covering combat simulation and field coordination.",
      icon: "ri-vr-line",
      clients: "Police, military, and emergency-response teams",
      features: [
        "VR/AR combat simulation",
        "Drone control training",
        "Field coordination exercises",
        "Emergency response scenarios",
        "Performance assessment tools"
      ]
    },
    {
      title: "Smart Manufacturing & Equipment Assembly",
      description: "Local assembly of UAVs, cameras, and defence electronics for government and private projects through Build-to-Order or Joint Manufacturing models.",
      icon: "ri-robot-line",
      clients: "Government and private sector projects",
      features: [
        "UAV local assembly",
        "Defence electronics manufacturing",
        "Build-to-Order services",
        "Joint Manufacturing partnerships",
        "Quality control systems"
      ]
    },
    {
      title: "Secure Communication & Encryption Deployment",
      description: "Installation and maintenance of encrypted communication systems, command centers, and field networks with national C2I system integration.",
      icon: "ri-lock-line",
      clients: "Government agencies and defence organizations",
      features: [
        "Encrypted communication systems",
        "Command center setup",
        "Field network deployment",
        "C2I system integration",
        "Ongoing maintenance support"
      ]
    },
    {
      title: "Defence Consultancy & Integration Services",
      description: "Turnkey project design for defence infrastructure, combining hardware, AI, and field systems through joint-venture or advisory contracts.",
      icon: "ri-user-settings-line",
      clients: "Ministries and government agencies",
      features: [
        "Turnkey project design",
        "Defence infrastructure planning",
        "Hardware-AI integration",
        "Field system deployment",
        "Strategic advisory services"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section 
        className="relative bg-cover bg-center bg-no-repeat py-24"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.5)), url('https://readdy.ai/api/search-image?query=Advanced%20military%20command%20center%20with%20multiple%20screens%20showing%20surveillance%20data%2C%20electronic%20warfare%20systems%2C%20and%20training%20simulations%2C%20professional%20defense%20facility%20with%20high-tech%20equipment%20and%20blue%20lighting%20atmosphere&width=1920&height=800&seq=7&orientation=landscape')`
        }}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h1 className="text-5xl lg:text-6xl font-bold text-white mb-6">
            Defence <strong>Services</strong> & Solutions
          </h1>
          <p className="text-xl text-gray-200 max-w-3xl mx-auto leading-relaxed">
            Comprehensive defence services combining advanced technology, training, and support systems for national security operations across Nigeria.
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Our <strong>Service</strong> Portfolio
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Specialized defence services designed to enhance security capabilities and operational effectiveness across government agencies, private sector, and critical infrastructure.
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <div key={index} className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow">
                <div className="flex items-start space-x-6">
                  <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <i className={`${service.icon} text-blue-600 text-2xl`}></i>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
                    <p className="text-gray-600 mb-4 leading-relaxed">{service.description}</p>
                    
                    <div className="mb-4">
                      <h4 className="text-sm font-semibold text-gray-900 mb-2">Target Clients:</h4>
                      <p className="text-sm text-blue-600 font-medium">{service.clients}</p>
                    </div>
                    
                    <div className="mb-4">
                      <h4 className="text-sm font-semibold text-gray-900 mb-2">Key Features:</h4>
                      <ul className="space-y-1">
                        {service.features.slice(0, 3).map((feature, featureIndex) => (
                          <li key={featureIndex} className="flex items-center text-sm text-gray-600">
                            <div className="w-3 h-3 bg-blue-600 rounded-full flex items-center justify-center mr-2 flex-shrink-0">
                              <i className="ri-check-line text-white text-xs"></i>
                            </div>
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    <button className="text-blue-600 font-semibold hover:text-blue-700 transition-colors cursor-pointer">
                      Request Quote <i className="ri-arrow-right-line ml-1"></i>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Service Categories */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Service <strong>Categories</strong>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our services are organized into key categories to serve different aspects of national security and defence operations.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center p-6 bg-gray-50 rounded-xl">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-eye-line text-blue-600 text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Surveillance Services</h3>
              <p className="text-gray-600 text-sm">Real-time monitoring and patrol services using advanced drone technology</p>
            </div>
            
            <div className="text-center p-6 bg-gray-50 rounded-xl">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-shield-check-line text-blue-600 text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Security Protection</h3>
              <p className="text-gray-600 text-sm">Cyber defence and electronic warfare protection systems</p>
            </div>
            
            <div className="text-center p-6 bg-gray-50 rounded-xl">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-brain-line text-blue-600 text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Intelligence Analytics</h3>
              <p className="text-gray-600 text-sm">AI-driven data analysis and signal intelligence services</p>
            </div>
            
            <div className="text-center p-6 bg-gray-50 rounded-xl">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-tools-line text-blue-600 text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Manufacturing & Training</h3>
              <p className="text-gray-600 text-sm">Equipment assembly and VR/AR training programs</p>
            </div>
          </div>
        </div>
      </section>

      {/* Integration Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                Integrated <strong>Defence Ecosystem</strong>
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                Our services work seamlessly together to create a comprehensive defence ecosystem that enhances operational efficiency and security effectiveness across Nigeria.
              </p>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center mt-1">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Local Expertise</h4>
                    <p className="text-gray-600">Nigerian-built solutions tailored for local security challenges</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center mt-1">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">24/7 Operations</h4>
                    <p className="text-gray-600">Round-the-clock monitoring and support services</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center mt-1">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Flexible Contracts</h4>
                    <p className="text-gray-600">Per-mission, hourly, or annual service agreements available</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://readdy.ai/api/search-image?query=Modern%20defense%20operations%20center%20with%20integrated%20systems%2C%20multiple%20workstations%20showing%20surveillance%20feeds%2C%20communication%20networks%2C%20and%20training%20simulations%2C%20professional%20military%20facility%20with%20advanced%20technology&width=600&height=500&seq=8&orientation=landscape"
                alt="Integrated defence ecosystem"
                className="rounded-lg shadow-xl object-cover w-full h-96"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-indigo-700">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Enhance Your <strong>Defence Capabilities</strong>?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Contact us to discuss how our comprehensive defence services can strengthen your security operations and operational effectiveness across Nigeria.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-blue-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-colors whitespace-nowrap cursor-pointer">
              Request Consultation
            </button>
            <button className="border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors whitespace-nowrap cursor-pointer">
              Download Service Catalog
            </button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default ServicesPage;
