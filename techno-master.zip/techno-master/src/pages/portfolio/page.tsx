
import { useState } from 'react';
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';

const PortfolioPage = () => {
  const [activeCategory, setActiveCategory] = useState('all');

  const categories = [
    { id: 'all', name: 'All Projects' },
    { id: 'meetings', name: 'Corporate Meetings' },
    { id: 'events', name: 'Events & Conferences' },
    { id: 'projects', name: 'Project Deployments' },
    { id: 'training', name: 'Training Programs' },
  ];

  const portfolioItems = [
    {
      id: 1,
      title: 'DICON Collaboration Meeting',
      category: 'meetings',
      description: 'Strategic collaboration meeting with Defence Industries Corporation of Nigeria to strengthen local defence manufacturing capabilities.',
      image: 'https://static.readdy.ai/image/3d693276a5424479ffa5f1cc868e7c58/2cb6b9b3d0eaa4303bfca6d9df463ee5.jpeg',
      date: 'October 2025'
    },
    {
      id: 2,
      title: 'Official Visit to Minister of Defence',
      category: 'meetings',
      description: 'High-level meeting with His Excellency Alh Badaru, Minister of Defence, and the Permanent Secretary of Defence to discuss strategic defence initiatives and technology partnerships.',
      image: 'https://static.readdy.ai/image/3d693276a5424479ffa5f1cc868e7c58/4b77d67e7dfe40224dbdca6af7cbcf5c.jpeg',
      date: 'March 2024'
    },
    {
      id: 3,
      title: 'Border Surveillance System Deployment',
      category: 'projects',
      description: "Successful deployment of integrated surveillance system along Nigeria's northern border regions.",
      image: 'https://static.readdy.ai/image/3d693276a5424479ffa5f1cc868e7c58/886460ec3be70e4151eae83fd3060600.jpeg',
      date: 'February 2024'
    },
    {
      id: 3,
      title: 'Strategic Partnership Meeting',
      category: 'meetings',
      description: 'High-level meeting with international defence technology partners to strengthen collaboration.',
      image: 'https://static.readdy.ai/image/3d693276a5424479ffa5f1cc868e7c58/6c64524157e397c89812446a871a4c1b.jpeg',
      date: 'January 2024'
    },
    {
      id: 4,
      title: 'Military Personnel Training Program',
      category: 'training',
      description: 'Comprehensive training program for military personnel on advanced UAV operations and cyber defence.',
      image: 'https://static.readdy.ai/image/3d693276a5424479ffa5f1cc868e7c58/e48beefb12ec6c5b8bc87ab450514821.jpeg',
      date: 'December 2023'
    },
    {
      id: 5,
      title: 'AI Intelligence Platform Launch',
      category: 'events',
      description: 'Official launch event for our revolutionary AI-driven intelligence fusion platform.',
      image: 'https://static.readdy.ai/image/3d693276a5424479ffa5f1cc868e7c58/c69c641da1b19821a9ceb8014656e358.jpeg',
      date: 'November 2023'
    },
    {
      id: 6,
      title: 'Cyber Defence Command Center',
      category: 'projects',
      description: 'Installation of state-of-the-art cyber defence command center for national security operations.',
      image: 'https://static.readdy.ai/image/3d693276a5424479ffa5f1cc868e7c58/a7b43fb43cc91cc64dbab4869ad2f9cf.jpeg',
      date: 'October 2023'
    },
    {
      id: 7,
      title: 'Government Security Briefing',
      category: 'meetings',
      description: 'Briefing session with government officials on national security technology initiatives.',
      image: 'https://static.readdy.ai/image/3d693276a5424479ffa5f1cc868e7c58/b57b29d6b1925089bd4d678222ef9a64.jpeg',
      date: 'September 2023'
    },
    {
      id: 8,
      title: 'Advanced UAV Training Workshop',
      category: 'training',
      description: 'Specialized workshop for advanced UAV mission planning and autonomous flight operations.',
      image: 'https://static.readdy.ai/image/3d693276a5424479ffa5f1cc868e7c58/0734c2e781e47e5e39bf4ab44ccdbae0.jpeg',
      date: 'August 2023'
    },
    {
      id: 9,
      title: 'International Defence Expo',
      category: 'events',
      description: 'Participation in major international defence exhibition showcasing Nigerian defence capabilities.',
      image: 'https://static.readdy.ai/image/3d693276a5424479ffa5f1cc868e7c58/86884dfa3714bd7667d388644a6732de.jpeg',
      date: 'July 2023'
    },
    {
      id: 10,
      title: 'Strategic Defence Partnership Summit',
      category: 'meetings',
      description: 'High-level diplomatic meeting with international partners to discuss defence technology cooperation and strategic alliances.',
      image: 'https://static.readdy.ai/image/3d693276a5424479ffa5f1cc868e7c58/037fe81e30bfe9ac4b0c74cb8544484e.jpeg',
      date: 'June 2023'
    },
    {
      id: 11,
      title: 'DIA Strategic Intelligence Briefing',
      category: 'meetings',
      description: 'Official visit to the Defence Intelligence Agency with Chief of Defence Intelligence to discuss strategic intelligence cooperation and technology integration.',
      image: 'https://static.readdy.ai/image/3d693276a5424479ffa5f1cc868e7c58/aec69ffb2069bba60d57e362a8ee20a2.png',
      date: 'May 2023'
    }
  ];

  const filteredItems = activeCategory === 'all' 
    ? portfolioItems 
    : portfolioItems.filter(item => item.category === activeCategory);

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section 
        className="relative bg-cover bg-center bg-no-repeat py-24"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.5)), url('https://readdy.ai/api/search-image?query=Professional%20corporate%20portfolio%20showcase%20with%20Nigerian%20defense%20technology%20projects%2C%20modern%20presentation%20hall%20with%20multiple%20screens%20displaying%20UAV%20systems%20and%20AI%20platforms%2C%20executive%20presentation%20setting&width=1920&height=800&seq=28&orientation=landscape')`
        }}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h1 className="text-5xl lg:text-6xl font-bold text-white mb-6">
            Our <strong>Portfolio</strong>
          </h1>
          <p className="text-xl text-gray-200 max-w-3xl mx-auto leading-relaxed">
            Showcasing our successful projects, strategic partnerships, and milestone achievements in advancing Nigeria's defence technology capabilities.
          </p>
        </div>
      </section>

      {/* Portfolio Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`px-6 py-3 rounded-full font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  activeCategory === category.id
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover-bg-gray-200'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>

          {/* Portfolio Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredItems.map((item) => (
              <div key={item.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
                <div className="h-64 overflow-hidden">
                  <img 
                    src={item.image}
                    alt={item.title}
                    className="w-full h-full object-cover object-top hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-6">
                  <div className="text-sm text-blue-600 font-medium mb-2">{item.date}</div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{item.title}</h3>
                  <p className="text-gray-600 leading-relaxed mb-4">{item.description}</p>
                  <button className="text-blue-600 font-semibold hover:text-blue-700 transition-colors cursor-pointer">
                    View Details <i className="ri-arrow-right-line ml-1"></i>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Project <strong>Achievements</strong>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Measurable impact across our portfolio of defence technology projects and initiatives.
            </p>
          </div>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-blue-600 mb-2">50+</div>
              <div className="text-gray-600 font-medium">Completed Projects</div>
            </div>
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-blue-600 mb-2">25+</div>
              <div className="text-gray-600 font-medium">Strategic Partnerships</div>
            </div>
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-blue-600 mb-2">500+</div>
              <div className="text-gray-600 font-medium">Personnel Trained</div>
            </div>
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-blue-600 mb-2">15+</div>
              <div className="text-gray-600 font-medium">Awards Received</div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Client <strong>Testimonials</strong>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Feedback from our valued partners and clients on our defence technology solutions.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-gray-50 rounded-xl p-8">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-user-line text-white text-xl"></i>
                </div>
                <div>
                  <h4 className="font-bold text-gray-900">Gen. Adamu Ibrahim</h4>
                  <p className="text-gray-600 text-sm">Chief of Defence Staff</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "Technoguard's UAV systems have significantly enhanced our border surveillance capabilities. Their technology is world-class."
              </p>
            </div>
            <div className="bg-gray-50 rounded-xl p-8">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-user-line text-white text-xl"></i>
                </div>
                <div>
                  <h4 className="font-bold text-gray-900">Dr. Amina Hassan</h4>
                  <p className="text-gray-600 text-sm">Director, National Security</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "The AI intelligence platform has revolutionized our threat detection and response capabilities. Exceptional innovation."
              </p>
            </div>
            <div className="bg-gray-50 rounded-xl p-8">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-user-line text-white text-xl"></i>
                </div>
                <div>
                  <h4 className="font-bold text-gray-900">Col. Emeka Okafor</h4>
                  <p className="text-gray-600 text-sm">Operations Commander</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "Outstanding training programs and technical support. Technoguard truly understands our operational requirements."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-indigo-700">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Join Our <strong>Success Stories</strong>?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Partner with Technoguard Nigeria Ltd to become part of our growing portfolio of successful defence technology implementations.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-blue-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-colors whitespace-nowrap cursor-pointer">
              Start Your Project
            </button>
            <button className="border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors whitespace-nowrap cursor-pointer">
              View Case Studies
            </button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default PortfolioPage;
