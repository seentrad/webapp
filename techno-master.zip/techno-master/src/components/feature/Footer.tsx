
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                <i className="ri-shield-check-line text-white text-xl"></i>
              </div>
              <div>
                <h3 className="text-xl font-bold">Technoguard</h3>
                <p className="text-sm text-gray-400">Nigeria Ltd</p>
              </div>
            </div>
            <p className="text-gray-400 mb-4">
              Developing advanced defence and surveillance technologies for national security and industrial growth.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors cursor-pointer">
                <i className="ri-linkedin-fill text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors cursor-pointer">
                <i className="ri-twitter-fill text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors cursor-pointer">
                <i className="ri-facebook-fill text-xl"></i>
              </a>
            </div>
          </div>

          {/* Solutions */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Solutions</h4>
            <ul className="space-y-2">
              <li><Link to="/software" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Software Solutions</Link></li>
              <li><Link to="/hardware" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Hardware Products</Link></li>
              <li><Link to="/services" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Defence Services</Link></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Training & Simulation</a></li>
            </ul>
          </div>

          {/* Technologies */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Technologies</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors cursor-pointer">UAV Systems</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors cursor-pointer">AI Intelligence</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Cyber Defence</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Surveillance</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact</h4>
            <div className="space-y-2">
              <p className="text-gray-400 flex items-center">
                <i className="ri-map-pin-line mr-2"></i>
                Nigeria
              </p>
              <p className="text-gray-400 flex items-center">
                <i className="ri-phone-line mr-2"></i>
                +2348032676787
              </p>
              <p className="text-gray-400 flex items-center">
                <i className="ri-mail-line mr-2"></i>
                info@technoguard.tech
              </p>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">
            © 2025 Technoguard Nigeria Ltd. All rights reserved.
          </p>
          <div className="flex items-center space-x-4 mt-4 md:mt-0">
            <Link to="/privacy" className="text-gray-400 hover:text-white text-sm transition-colors cursor-pointer">Privacy Policy</Link>
            <Link to="/terms" className="text-gray-400 hover:text-white text-sm transition-colors cursor-pointer">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
