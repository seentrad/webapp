<?php
include("includes/db.php");
include("functions/functions.php");

if(isset($_POST['pay_now'])) {
    $customer_id = $_POST['customer_id'];
    $amount = $_POST['amount'];
    $email = $_POST['email'];
    $cart_items = json_decode($_POST['cart_items'], true);

    $tx_ref = "TX_" . time();
    $callback_url = "https://riglandtravels.com/bobtextiles/flutterwave_callback.php"; // Ensure it's HTTPS

    // ✅ Use your actual Flutterwave Secret Key here
    $secret_key = "FLWSECK_TEST-bbf28f4d25b8d36ade3bc441967b22f5-X";  

    $postData = [
        "tx_ref" => $tx_ref,
        "amount" => $amount,
        "currency" => "NGN",
        "redirect_url" => $callback_url,
        "customer" => [
            "email" => $email
        ],
        "meta" => [
            "customer_id" => $customer_id
        ],
        "customizations" => [
            "title" => "BOB TEXTILE Checkout",
            "description" => "Payment for selected items"
        ]
    ];

    // ✅ Initialize cURL
    $ch = curl_init("https://api.flutterwave.com/v3/payments");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer $secret_key",
        "Content-Type: application/json"
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));

    $response = curl_exec($ch);
    $curl_error = curl_error($ch);
    curl_close($ch);

    $result = json_decode($response, true);

    // ✅ Check if there's a cURL error
    if ($curl_error) {
        die("cURL Error: " . $curl_error);
    }

    // ✅ Check Flutterwave response
    if(isset($result['status']) && $result['status'] === "success") {
        header("Location: " . $result['data']['link']);
        exit();
    } else {
        // Show error response from Flutterwave
        echo "Payment initialization failed. Error: " . ($result['message'] ?? "Unknown error");
    }
}
?>
