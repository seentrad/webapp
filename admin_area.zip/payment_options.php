<div class="box"><!-- box Starts -->

<?php
$session_email = $_SESSION['customer_email'];

$select_customer = "SELECT * FROM customers WHERE customer_email='$session_email'";
$run_customer = mysqli_query($con, $select_customer);
$row_customer = mysqli_fetch_array($run_customer);
$customer_id = $row_customer['customer_id'];

$total_amount = 0;
$ip_add = getRealUserIp();

$get_cart = "SELECT * FROM cart WHERE ip_add='$ip_add'";
$run_cart = mysqli_query($con, $get_cart);

$cart_items = [];

while ($row_cart = mysqli_fetch_array($run_cart)) {
    $pro_id = $row_cart['p_id'];
    $pro_qty = $row_cart['qty'];
    $pro_price = $row_cart['p_price'];

    $get_products = "SELECT * FROM products WHERE product_id='$pro_id'";
    $run_products = mysqli_query($con, $get_products);
    $row_products = mysqli_fetch_array($run_products);
    $product_title = $row_products['product_title'];

    $total_amount += ($pro_price * $pro_qty);
    $cart_items[] = [
        "id" => $pro_id,
        "name" => $product_title,
        "quantity" => $pro_qty,
        "price" => $pro_price
    ];
}
?>

<h1 class="text-center">Payment Options For You</h1>

<p class="lead text-center">
    <a href="order.php?c_id=<?php echo $customer_id; ?>">Pay Offline</a>
</p>

<center><!-- center Starts -->

<!-- Flutterwave Payment Form -->
<form method="POST" action="flutterwave_payment.php">
    <input type="hidden" name="customer_id" value="<?php echo $customer_id; ?>">
    <input type="hidden" name="amount" value="<?php echo $total_amount; ?>">
    <input type="hidden" name="cart_items" value='<?php echo json_encode($cart_items); ?>'>
    <input type="hidden" name="email" value="<?php echo $session_email; ?>">
    <button type="submit" name="pay_now">
        <img src="images/flutterwave.png" width="250" height="100" alt="Flutterwave Pay">
    </button>
</form>

</center><!-- center Ends -->

</div><!-- box Ends -->
