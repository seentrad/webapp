<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>B.O.B TEXTILE</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .footer {
            background-color: #333;
            color: white;
            padding: 20px 0;
            margin-top: auto;
            text-align: center;
        }

        .footer-container {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 20px;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .footer-section {
            flex: 1;
            min-width: 200px;
            text-align: left;
        }

        .footer-section h3 {
            font-size: 1.2rem;
            margin-bottom: 10px;
        }

        .footer-section ul {
            list-style: none;
            padding: 0;
        }

        .footer-section ul li {
            margin: 5px 0;
        }

        .footer-section ul li a {
            color: white;
            text-decoration: none;
        }

        .footer-section ul li a:hover {
            color: #ff6f61;
        }

        .footer-bottom {
            margin-top: 20px;
            padding-top: 10px;
            border-top: 1px solid #555;
        }

        /* Mobile View */
        @media (max-width: 768px) {
            .footer-container {
                flex-direction: column;
                align-items: center;
                text-align: center;
            }

            .footer-section {
                min-width: 100%;
            }
        }
    </style>
</head>
<body>
    <?php
    session_start();
    include("includes/db.php");
    include("includes/header.php");
    include("functions/functions.php");
    include("includes/main.php");
    ?>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-content">
            <h1>Welcome to Our Store</h1>
            <p>Discover the best products at amazing prices</p>
            <a href="shop.php" class="btn">Shop Now</a>
        </div>
    </section>

    <!-- Featured Products Section -->
    <section class="featured-products">
        <div class="container">
            <h2>Featured Collection</h2>
            <div class="product-grid">
                <?php getPro(); ?>
            </div>
        </div>
    </section>
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-section">
                <h3>Information</h3>
                <ul>
                    <li><a href="#">The Brand</a></li>
                    <li><a href="#">Local Stores</a></li>
                    <li><a href="#">Customer Service</a></li>
                    <li><a href="#">Privacy & Cookies</a></li>
                    <li><a href="#">Site Map</a></li>
                </ul>
            </div>

            <div class="footer-section">
                <h3>Why Buy From Us</h3>
                <ul>
                    <li><a href="#">Shipping & Returns</a></li>
                    <li><a href="#">Secure Shopping</a></li>
                    <li><a href="#">Testimonials</a></li>
                    <li><a href="#">Award Winning</a></li>
                    <li><a href="#">Ethical Trading</a></li>
                </ul>
            </div>

            <div class="footer-section">
                <h3>Your Account</h3>
                <ul>
                    <li><a href="#">Sign In</a></li>
                    <li><a href="#">Register</a></li>
                    <li><a href="#">View Cart</a></li>
                    <li><a href="#">Track Order</a></li>
                    <li><a href="#">Update Info</a></li>
                </ul>
            </div>

            <div class="footer-section">
                <h3>Contact Details</h3>
                <address>
                    Head Office: Bob Textiles<br>
                    Abuja, Nigeria
                </address>
                <p>Telephone: <a href="tel:08100176410">08100176410</a></p>
                <p>Email: <a href="mailto:support@bobtextiles.org">support@bobtextiles.org</a></p>
            </div>
        </div>
        <div class="footer-bottom">
            &copy; <?php echo date("Y"); ?> Ecommerce Store. All rights reserved.
        </div>
    </footer>
</body>
</html>