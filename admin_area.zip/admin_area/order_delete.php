<?php
if (!isset($_SESSION['admin_email'])) {
    echo "<script>window.open('login.php','_self')</script>";
    exit();
}

if (isset($_GET['order_delete'])) {
    include("includes/db.php"); // Ensure the database connection is included

    $delete_id = mysqli_real_escape_string($con, $_GET['order_delete']);
    
    // Ensure order exists before deleting
    $check_order = "SELECT * FROM customer_orders WHERE order_id='$delete_id'";
    $run_check = mysqli_query($con, $check_order);

    if (mysqli_num_rows($run_check) > 0) {
        // Delete order from `customer_orders` table
        $delete_order = "DELETE FROM customer_orders WHERE order_id='$delete_id'";
        $run_delete = mysqli_query($con, $delete_order);

        if ($run_delete) {
            echo "
            <div style='position: fixed; top: 20px; right: 20px; background: #d9534f; color: #fff; padding: 15px; border-radius: 5px; box-shadow: 0px 0px 10px rgba(0,0,0,0.2);'>
                <strong>✅ Order Deleted Successfully!</strong>
            </div>
            <script>
                setTimeout(function(){
                    window.location.href = 'index.php?view_orders';
                }, 2000);
            </script>";
        } else {
            echo "<script>alert('Error deleting order.')</script>";
        }
    } else {
        echo "<script>alert('Order does not exist!')</script>";
    }
}
?>
