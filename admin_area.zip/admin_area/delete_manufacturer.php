<?php
session_start();
if (!isset($_SESSION['admin_email'])) {
    echo "<script>window.open('login.php','_self');</script>";
    exit();
}

if (isset($_GET['delete_manufacturer'])) {
    include("includes/db.php"); // Ensure database connection

    $delete_id = mysqli_real_escape_string($con, $_GET['delete_manufacturer']);

    // Check if manufacturer exists before deleting
    $check_manufacturer = "SELECT * FROM manufacturers WHERE manufacturer_id='$delete_id'";
    $run_check = mysqli_query($con, $check_manufacturer);

    if (mysqli_num_rows($run_check) > 0) {
        $delete_manufacturer = "DELETE FROM manufacturers WHERE manufacturer_id='$delete_id'";
        $run_manufacturer = mysqli_query($con, $delete_manufacturer);

        if ($run_manufacturer) {
            echo "
            <div style='position: fixed; top: 20px; right: 20px; background: #5cb85c; color: #fff; padding: 15px; border-radius: 5px; box-shadow: 0px 0px 10px rgba(0,0,0,0.2);'>
                ✅ <strong>Manufacturer Deleted Successfully!</strong>
            </div>
            <script>
                setTimeout(function(){
                    window.location.href = 'index.php?view_manufacturers';
                }, 2000);
            </script>";
        } else {
            echo "<script>alert('Error deleting manufacturer.')</script>";
        }
    } else {
        echo "<script>alert('Manufacturer does not exist!')</script>";
    }
}
?>
