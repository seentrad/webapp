<?php
if (!isset($_SESSION['admin_email'])) {
    echo "<script>window.open('login.php','_self')</script>";
    exit();
}

if (isset($_GET['delete_store'])) {
    include("includes/db.php"); // Ensure database connection is included

    $delete_id = mysqli_real_escape_string($con, $_GET['delete_store']);

    // Check if the store exists before deleting
    $check_store = "SELECT * FROM store WHERE store_id='$delete_id'";
    $run_check = mysqli_query($con, $check_store);

    if (mysqli_num_rows($run_check) > 0) {
        // Delete from `store` table
        $delete_store = "DELETE FROM store WHERE store_id='$delete_id'";
        $run_delete = mysqli_query($con, $delete_store);

        if ($run_delete) {
            echo "
            <div style='position: fixed; top: 20px; right: 20px; background: #d9534f; color: #fff; padding: 15px; border-radius: 5px; box-shadow: 0px 0px 10px rgba(0,0,0,0.2);'>
                <strong>✅ Store Deleted Successfully!</strong>
            </div>
            <script>
                setTimeout(function(){
                    window.location.href = 'index.php?view_store';
                }, 2000);
            </script>";
        } else {
            echo "<script>alert('Error deleting store.')</script>";
        }
    } else {
        echo "<script>alert('Store does not exist!')</script>";
    }
}
?>
