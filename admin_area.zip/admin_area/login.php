<?php
session_start();
include("includes/db.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>B.O.B TEXTILE - Admin Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: black;
            overflow: hidden;
            position: relative;
        }

        .login-container {
            background: rgba(255, 255, 255, 0.1);
            padding: 2.5rem;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            margin: 1rem;
            backdrop-filter: blur(10px);
            position: relative;
            z-index: 2;
        }

        h1 {
            color: white;
            margin-bottom: 2rem;
            text-align: center;
            font-size: 2em;
        }

        .form-group {
            margin-bottom: 1.5rem;
            position: relative;
        }

        label {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #636e72;
            transition: all 0.3s ease;
            pointer-events: none;
        }

        input {
            width: 100%;
            padding: 15px;
            border: 2px solid #dfe6e9;
            border-radius: 10px;
            font-size: 1em;
            transition: border-color 0.3s ease;
            background: rgba(255, 255, 255, 0.8);
        }

        input:focus {
            outline: none;
            border-color: #ff7675;
        }

        input:focus+label,
        input:not(:placeholder-shown)+label {
            top: -10px;
            left: 10px;
            font-size: 0.8em;
            background: rgba(255, 255, 255, 0.8);
            padding: 0 5px;
            color: #ff7675;
        }

        .forgot-password {
            text-align: right;
            margin: 1rem 0;
        }

        .forgot-password a {
            color: #636e72;
            text-decoration: none;
            font-size: 0.9em;
        }

        .forgot-password a:hover {
            color: #ff7675;
            text-decoration: underline;
        }

        button {
            width: 100%;
            padding: 15px;
            background: #ff7675;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1.1em;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        button:hover {
            background: #d63031;
        }

        .moving-box {
            position: absolute;
            width: 100px;
            height: 100px;
            background: linear-gradient(45deg, red, black);
            z-index: 1;
            pointer-events: none;
            transform: translate(-50%, -50%);
            transition: all 0.1s ease;
        }

        @media (max-width: 480px) {
            .login-container {
                padding: 1.5rem;
            }
        }
    </style>
</head>

<body>
    <div class="moving-box" id="movingBox"></div>
    <div class="login-container">
        <h1>B.O.B TEXTILE</h1>
        <form class="form-login" action="" method="post">
            <div class="form-group">
                <input type="text" name="admin_email" id="admin_email" placeholder=" " required>
                <label for="admin_email">Email Address</label>
            </div>

            <div class="form-group">
                <input type="password" name="admin_pass" id="admin_pass" placeholder=" " required>
                <label for="admin_pass">Password</label>
            </div>

            <div class="forgot-password">
                <a href="#">Forgot Password?</a>
            </div>

            <button type="submit" name="admin_login">Login</button>
        </form>
    </div>

    <script>
        const movingBox = document.getElementById('movingBox');

        document.addEventListener('mousemove', (e) => {
            movingBox.style.left = `${e.pageX}px`;
            movingBox.style.top = `${e.pageY}px`;
        });
    </script>
</body>

</html>

<?php
if (isset($_POST['admin_login'])) {
    $admin_email = mysqli_real_escape_string($con, $_POST['admin_email']);
    $admin_pass = mysqli_real_escape_string($con, $_POST['admin_pass']);

    $get_admin = "select * from admins where admin_email='$admin_email' AND admin_pass='$admin_pass'";
    $run_admin = mysqli_query($con, $get_admin);
    $count = mysqli_num_rows($run_admin);

    if ($count == 1) {
        $_SESSION['admin_email'] = $admin_email;
        // Silent login - no alert message
        echo "<script>window.open('index.php?dashboard','_self')</script>";
    } else {
        echo "<script>alert('Email or Password is Wrong')</script>";
    }
}
?>