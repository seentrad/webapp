<?php
if (!isset($_SESSION['admin_email'])) {
    echo "<script>window.open('login.php','_self')</script>";
    exit();
}

if (isset($_GET['delete_term'])) {
    include("includes/db.php"); // Ensure database connection is included

    $delete_id = mysqli_real_escape_string($con, $_GET['delete_term']);

    // Check if the term exists before deleting
    $check_term = "SELECT * FROM terms WHERE term_id='$delete_id'";
    $run_check = mysqli_query($con, $check_term);

    if (mysqli_num_rows($run_check) > 0) {
        // Delete from `terms` table
        $delete_term = "DELETE FROM terms WHERE term_id='$delete_id'";
        $run_term = mysqli_query($con, $delete_term);

        if ($run_term) {
            echo "
            <div style='position: fixed; top: 20px; right: 20px; background: #d9534f; color: #fff; padding: 15px; border-radius: 5px; box-shadow: 0px 0px 10px rgba(0,0,0,0.2);'>
                <strong>✅ Term Deleted Successfully!</strong>
            </div>
            <script>
                setTimeout(function(){
                    window.location.href = 'index.php?view_terms';
                }, 2000);
            </script>";
        } else {
            echo "<script>alert('Error deleting term.')</script>";
        }
    } else {
        echo "<script>alert('Term does not exist!')</script>";
    }
}
?>
