<?php

$con = mysqli_connect("localhost","riglxyma_ecom","{;w[!lZs,(1b","riglxyma_ecom");

?>
