<?php
if (!isset($_SESSION['admin_email'])) {
    echo "<script>window.open('login.php','_self')</script>";
    exit();
}

if (isset($_GET['delete_p_cat'])) {
    include("includes/db.php"); // Ensure database connection

    $delete_p_cat_id = mysqli_real_escape_string($con, $_GET['delete_p_cat']);

    // Check if product category exists before deleting
    $check_p_cat = "SELECT * FROM product_categories WHERE p_cat_id='$delete_p_cat_id'";
    $run_check = mysqli_query($con, $check_p_cat);

    if (mysqli_num_rows($run_check) > 0) {
        // Delete product category from `product_categories` table
        $delete_p_cat = "DELETE FROM product_categories WHERE p_cat_id='$delete_p_cat_id'";
        $run_delete = mysqli_query($con, $delete_p_cat);

        if ($run_delete) {
            echo "
            <div style='position: fixed; top: 20px; right: 20px; background: #d9534f; color: #fff; padding: 15px; border-radius: 5px; box-shadow: 0px 0px 10px rgba(0,0,0,0.2);'>
                <strong>✅ Product Category Deleted Successfully!</strong>
            </div>
            <script>
                setTimeout(function(){
                    window.location.href = 'index.php?view_p_cats';
                }, 2000);
            </script>";
        } else {
            echo "<script>alert('Error deleting product category.')</script>";
        }
    } else {
        echo "<script>alert('Product category does not exist!')</script>";
    }
}
?>
