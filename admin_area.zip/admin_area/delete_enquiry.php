<?php
session_start();
if (!isset($_SESSION['admin_email'])) {
    echo "<script>window.open('login.php','_self');</script>";
    exit();
}

if (isset($_GET['delete_enquiry'])) {
    include("includes/db.php"); // Ensure database connection

    $delete_id = mysqli_real_escape_string($con, $_GET['delete_enquiry']);

    // Check if enquiry type exists before deleting
    $check_enquiry = "SELECT * FROM enquiry_types WHERE enquiry_id='$delete_id'";
    $run_check = mysqli_query($con, $check_enquiry);

    if (mysqli_num_rows($run_check) > 0) {
        $delete_enquiry = "DELETE FROM enquiry_types WHERE enquiry_id='$delete_id'";
        $run_delete = mysqli_query($con, $delete_enquiry);

        if ($run_delete) {
            echo "
            <div style='position: fixed; top: 20px; right: 20px; background: #5cb85c; color: #fff; padding: 15px; border-radius: 5px; box-shadow: 0px 0px 10px rgba(0,0,0,0.2);'>
                ✅ <strong>Enquiry Type Deleted Successfully!</strong>
            </div>
            <script>
                setTimeout(function(){
                    window.location.href = 'index.php?view_enquiry';
                }, 2000);
            </script>";
        } else {
            echo "<script>alert('Error deleting enquiry type.')</script>";
        }
    } else {
        echo "<script>alert('Enquiry type does not exist!')</script>";
    }
}
?>
