<?php
if (!isset($_SESSION['admin_email'])) {
    echo "<script>window.open('login.php','_self')</script>";
    exit();
}

if (isset($_GET['payment_delete'])) {
    include("includes/db.php"); // Ensure database connection is included

    $delete_id = mysqli_real_escape_string($con, $_GET['payment_delete']);

    // Check if the payment exists before deleting
    $check_payment = "SELECT * FROM payments WHERE payment_id='$delete_id'";
    $run_check = mysqli_query($con, $check_payment);

    if (mysqli_num_rows($run_check) > 0) {
        // Delete from `payments` table
        $delete_payment = "DELETE FROM payments WHERE payment_id='$delete_id'";
        $run_delete = mysqli_query($con, $delete_payment);

        if ($run_delete) {
            echo "
            <div style='position: fixed; top: 20px; right: 20px; background: #d9534f; color: #fff; padding: 15px; border-radius: 5px; box-shadow: 0px 0px 10px rgba(0,0,0,0.2);'>
                <strong>✅ Payment Deleted Successfully!</strong>
            </div>
            <script>
                setTimeout(function(){
                    window.location.href = 'index.php?view_payments';
                }, 2000);
            </script>";
        } else {
            echo "<script>alert('Error deleting payment.')</script>";
        }
    } else {
        echo "<script>alert('Payment does not exist!')</script>";
    }
}
?>
