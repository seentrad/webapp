<?php
session_start();
if (!isset($_SESSION['admin_email'])) {
    echo "<script>window.open('login.php','_self');</script>";
    exit();
}

if (isset($_GET['delete_coupon'])) {
    include("includes/db.php"); // Ensure database connection

    $delete_id = mysqli_real_escape_string($con, $_GET['delete_coupon']);

    // Check if the coupon exists before attempting to delete
    $check_coupon = "SELECT * FROM coupons WHERE coupon_id='$delete_id'";
    $run_check = mysqli_query($con, $check_coupon);

    if (mysqli_num_rows($run_check) > 0) {
        $delete_coupon = "DELETE FROM coupons WHERE coupon_id='$delete_id'";
        $run_delete = mysqli_query($con, $delete_coupon);

        if ($run_delete) {
            echo "
            <div style='position: fixed; top: 20px; right: 20px; background: #5cb85c; color: #fff; padding: 15px; border-radius: 5px; box-shadow: 0px 0px 10px rgba(0,0,0,0.2);'>
                ✅ <strong>Coupon Deleted Successfully!</strong>
            </div>
            <script>
                setTimeout(function(){
                    window.location.href = 'index.php?view_coupons';
                }, 2000);
            </script>";
        } else {
            echo "<script>alert('Error deleting coupon. Please try again.');</script>";
        }
    } else {
        echo "<script>alert('Coupon does not exist!');</script>";
    }
}
?>
