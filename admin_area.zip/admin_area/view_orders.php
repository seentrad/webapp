<?php
if (!isset($_SESSION['admin_email'])) {
    echo "<script>window.open('login.php','_self')</script>";
} else {
?>
<div class="row">
    <div class="col-lg-12">
        <ol class="breadcrumb" style="background-color: #f8f9fa; color: #333;">
            <li class="active">
                <i class="fa fa-dashboard"></i> Dashboard / View Orders
            </li>
        </ol>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default" style="border-color: #ddd;">
            <div class="panel-heading" style="background-color: #f8f9fa; color: #333; border-color: #ddd;">
                <h3 class="panel-title">
                    <i class="fa fa-money fa-fw"></i> View Orders
                </h3>
            </div>

            <div class="panel-body" style="background-color: #fff; color: #333;">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover table-striped" style="color: #333;">
                        <thead>
                            <tr style="background-color: #f8f9fa; color: #333;">
                                <th>#</th>
                                <th>Customer</th>
                                <th>Invoice</th>
                                <th>Qty</th>
                                <th>Size</th>
                                <th>Order Date</th>
                                <th>Total Amount</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            $i = 0;
                            // Fetching orders from customer_orders instead of pending_orders
                            $get_orders = "SELECT * FROM customer_orders";
                            $run_orders = mysqli_query($con, $get_orders);

                            while ($row_orders = mysqli_fetch_assoc($run_orders)) {
                                $order_id = $row_orders['order_id'];
                                $c_id = $row_orders['customer_id'];
                                $invoice_no = $row_orders['invoice_no'];
                                $qty = $row_orders['qty'];
                                $size = $row_orders['size'];
                                $order_date = $row_orders['order_date'];
                                $due_amount = $row_orders['due_amount'];
                                $order_status = $row_orders['order_status'];

                                // Fetch customer email safely
                                $get_customer = "SELECT customer_email FROM customers WHERE customer_id='$c_id' LIMIT 1";
                                $run_customer = mysqli_query($con, $get_customer);
                                $customer_email = ($row_customer = mysqli_fetch_assoc($run_customer)) ? $row_customer['customer_email'] : 'Unknown';

                                $i++;
                            ?>
                            <tr style="background-color: #fff; color: #333;">
                                <td><?php echo $i; ?></td>
                                <td><?php echo $customer_email; ?></td>
                                <td style="background-color: #fff3cd; color: #333;"><?php echo $invoice_no; ?></td>
                                <td><?php echo $qty; ?></td>
                                <td><?php echo $size; ?></td>
                                <td><?php echo $order_date; ?></td>
                                <td>₦<?php echo number_format($due_amount, 2); ?></td>
                                <td>
                                    <?php
                                    if ($order_status == 'pending') {
                                        echo '<span style="color: #dc3545;">Pending</span>';
                                    } else {
                                        echo '<span style="color: #28a745;">Completed</span>';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <a href="index.php?order_delete=<?php echo $order_id; ?>" style="color: #dc3545;">
                                        <i class="fa fa-trash-o"></i> Delete
                                    </a>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php } ?>
