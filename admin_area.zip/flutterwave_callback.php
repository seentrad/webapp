<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include("includes/db.php");
include("functions/functions.php");

if (isset($_GET['status']) && $_GET['status'] === 'successful' && isset($_GET['transaction_id'])) {
    $transaction_id = $_GET['transaction_id'];
    $secret_key = "FLWSECK_TEST-bbf28f4d25b8d36ade3bc441967b22f5-X"; // 🔥 Replace with your actual Flutterwave Secret Key

    // Verify payment with Flutterwave API
    $ch = curl_init("https://api.flutterwave.com/v3/transactions/$transaction_id/verify");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer $secret_key",
        "Content-Type: application/json"
    ]);

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        die("cURL Error: " . curl_error($ch));
    }
    curl_close($ch);

    $result = json_decode($response, true);

    // ✅ Check if Flutterwave returned success
    if (isset($result['status']) && $result['status'] === "success") {
        $customer_id = $result['data']['meta']['customer_id'] ?? null;
        $amount_paid = $result['data']['amount'] ?? 0;
        $tx_ref = $result['data']['tx_ref'] ?? '';
        $invoice_no = mt_rand(); // Generate a unique invoice number
        $payment_mode = "Flutterwave";
        $payment_date = date("Y-m-d H:i:s");
        $status = "complete";
        $ip_add = getRealUserIp();

        if (!$customer_id) {
            die("Error: Customer ID missing in Flutterwave response");
        }

        // 🔍 Check if order already exists
        $check_order = mysqli_query($con, "SELECT * FROM customer_orders WHERE invoice_no='$invoice_no'");
        if (mysqli_num_rows($check_order) > 0) {
            die("Order already exists!");
        }

        // 💰 Insert payment
        $insert_payment = "INSERT INTO payments 
            (invoice_no, amount, payment_mode, ref_no, code, payment_date) 
            VALUES ('$invoice_no', '$amount_paid', '$payment_mode', '$tx_ref', '$transaction_id', '$payment_date')";
        if (!mysqli_query($con, $insert_payment)) {
            die("Error inserting payment: " . mysqli_error($con));
        }

        // 🛒 Process cart items
        $select_cart = mysqli_query($con, "SELECT * FROM cart WHERE ip_add='$ip_add'");
        while ($row_cart = mysqli_fetch_array($select_cart)) {
            $pro_id = $row_cart['p_id'];
            $pro_qty = $row_cart['qty'];
            $pro_size = $row_cart['size'];
            $sub_total = $row_cart['p_price'] * $pro_qty;

            $insert_customer_order = "INSERT INTO customer_orders 
                (customer_id, due_amount, invoice_no, qty, size, order_date, order_status) 
                VALUES ('$customer_id', '$sub_total', '$invoice_no', '$pro_qty', '$pro_size', NOW(), '$status')";
            if (!mysqli_query($con, $insert_customer_order)) {
                die("Error inserting customer order: " . mysqli_error($con));
            }
        }

        // 🗑 Clear cart
        if (!mysqli_query($con, "DELETE FROM cart WHERE ip_add='$ip_add'")) {
            die("Error clearing cart: " . mysqli_error($con));
        }

        // 🎉 Success message
        echo "
        <div style='display:flex; justify-content:center; align-items:center; height:100vh;'>
            <div style='text-align:center; padding:20px; border:2px solid #28a745; background:#f8fff8; border-radius:10px;'>
                <h2 style='color:#28a745;'>✅ Order Placed Successfully!</h2>
                <p>Thank you for your purchase. Your order number is <strong>$invoice_no</strong>.</p>
                <a href='customer/my_account.php?my_orders' style='padding:10px 15px; background:#28a745; color:#fff; text-decoration:none; border-radius:5px;'>View Orders</a>
            </div>
        </div>";
        exit();
    } else {
        die("Payment verification failed: " . ($result['message'] ?? "Unknown error"));
    }
} else {
    die("Invalid request: Payment was not successful or transaction_id is missing.");
}
?>
